package com.kevin.aquaconnect;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class EmployeeDashboardActivity extends AppCompatActivity {

    private TextView tvPendingCount, tvCompletedCount, tvEmpId;
    private String employeeId = "Emp123";   // ← Change later with real login

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_dashboard);

        tvPendingCount = findViewById(R.id.tvPendingCount);
        tvCompletedCount = findViewById(R.id.tvCompletedCount);
        tvEmpId = findViewById(R.id.tvEmpId);
        tvEmpId.setText(employeeId);

        findViewById(R.id.cardMyJobs).setOnClickListener(v ->
                startActivity(new Intent(this, MyJobsActivity.class)));

        findViewById(R.id.ivLogout).setOnClickListener(v -> finish());

        loadCounts();
    }

    private void loadCounts() {
        String dbUrl = "https://aqua-connect-e3324-default-rtdb.firebaseio.com/";
        DatabaseReference ref = FirebaseDatabase.getInstance(dbUrl).getReference("service_requests");

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                int pending = 0, completed = 0;
                for (DataSnapshot ds : snapshot.getChildren()) {
                    ServiceRequest req = ds.getValue(ServiceRequest.class);
                    if (req != null && employeeId.equals(req.getAssignedTo())) {
                        if ("Completed".equalsIgnoreCase(req.getStatus())) {
                            completed++;
                        } else {
                            pending++;
                        }
                    }
                }
                tvPendingCount.setText(String.valueOf(pending));
                tvCompletedCount.setText(String.valueOf(completed));
            }
            @Override public void onCancelled(DatabaseError error) {}
        });
    }
}