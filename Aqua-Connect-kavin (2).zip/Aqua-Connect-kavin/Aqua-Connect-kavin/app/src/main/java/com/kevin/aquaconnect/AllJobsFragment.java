package com.kevin.aquaconnect;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;

public class AllJobsFragment extends Fragment {

    private RecyclerView recyclerView;
    private EmployeeJobsAdapter adapter;
    private List<ServiceRequest> jobList = new ArrayList<>();
    private String employeeId = "Emp123";

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_jobs_list, container, false);

        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new EmployeeJobsAdapter(jobList, request -> {
            Intent i = new Intent(getContext(), JobDetailsActivity.class);
            i.putExtra("request", request);
            startActivity(i);
        });
        recyclerView.setAdapter(adapter);

        loadJobs();
        return view;
    }

    private void loadJobs() {
        String dbUrl = "https://aqua-connect-e3324-default-rtdb.firebaseio.com/";
        DatabaseReference ref = FirebaseDatabase.getInstance(dbUrl).getReference("service_requests");

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                jobList.clear();
                for (DataSnapshot ds : snapshot.getChildren()) {
                    ServiceRequest req = ds.getValue(ServiceRequest.class);
                    if (req != null && employeeId.equals(req.getAssignedTo())) {
                        jobList.add(req);
                    }
                }
                adapter.notifyDataSetChanged();
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }
}