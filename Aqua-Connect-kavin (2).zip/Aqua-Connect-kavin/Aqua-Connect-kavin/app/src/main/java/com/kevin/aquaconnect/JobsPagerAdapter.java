package com.kevin.aquaconnect;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class JobsPagerAdapter extends FragmentStateAdapter {
    public JobsPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0: return new AllJobsFragment();
            case 1: return new AssignedJobsFragment();
            case 2: return new CompletedJobsFragment();
            default: return new AllJobsFragment();
        }
    }

    @Override
    public int getItemCount() {
        return 3;
    }
}