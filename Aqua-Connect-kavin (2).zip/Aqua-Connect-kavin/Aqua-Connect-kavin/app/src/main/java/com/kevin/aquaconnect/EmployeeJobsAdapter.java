package com.kevin.aquaconnect;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class EmployeeJobsAdapter extends RecyclerView.Adapter<EmployeeJobsAdapter.ViewHolder> {

    private final List<ServiceRequest> list;
    private final OnJobClickListener listener;

    public interface OnJobClickListener {
        void onJobClick(ServiceRequest request);
    }

    public EmployeeJobsAdapter(List<ServiceRequest> list, OnJobClickListener listener) {
        this.list = list;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_request, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ServiceRequest req = list.get(position);

        holder.type.setText(req.getServiceType());
        holder.address.setText(req.getAddress());
        holder.urgency.setText("Urgency: " + req.getUrgency());

        String status = req.getStatus() != null ? req.getStatus() : "Assigned";
        holder.status.setText(status);

        if ("Completed".equalsIgnoreCase(status)) {
            holder.status.setTextColor(android.graphics.Color.GREEN);
        } else if ("Assigned".equalsIgnoreCase(status)) {
            holder.status.setTextColor(android.graphics.Color.BLUE);
        } else {
            holder.status.setTextColor(android.graphics.Color.GRAY);
        }

        holder.itemView.setOnClickListener(v -> listener.onJobClick(req));
    }

    @Override
    public int getItemCount() { return list.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView type, address, urgency, status;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            type = itemView.findViewById(R.id.tvHistoryServiceType);
            address = itemView.findViewById(R.id.tvHistoryAddress);
            urgency = itemView.findViewById(R.id.tvHistoryUrgency);
            status = itemView.findViewById(R.id.tvHistoryStatus);
        }
    }
}